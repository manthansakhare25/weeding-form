// scripts.js

function submitForm(event) {
    event.preventDefault(); // Prevent form from submitting normally

    const name = document.getElementById('name').value;
    const mobile = document.getElementById('mobile').value;
    const email = document.getElementById('email').value;
    const amount = document.getElementById('amount').value;
    const screenshot = document.getElementById('screenshot').files[0];
    const reason = document.getElementById('reason').value;
    const time = document.getElementById('time').value;
    const date = document.getElementById('date').value;

    // Validate WhatsApp number (simple check for 10 digits)
    const phonePattern = /^[0-9]{10}$/;
    if (!phonePattern.test(mobile)) {
        alert('Please enter a valid WhatsApp number');
        return;
    }

    // Check if all fields are filled
    if (!name || !mobile || !email || !amount || !screenshot || !reason || !time || !date) {
        alert('Please fill in all fields.');
        return;
    }

    // Create Excel file
    let wb = XLSX.utils.book_new();
    let ws_data = [
        ["Name", "Mobile", "Email", "Amount", "Screenshot", "Reason", "Time", "Date"],
        [name, mobile, email, amount, screenshot.name, reason, time, date]
    ];

    let ws = XLSX.utils.aoa_to_sheet(ws_data);
    XLSX.utils.book_append_sheet(wb, ws, "Expenses");

    // Generate Excel file download
    XLSX.writeFile(wb, "wedding_expenses.xlsx");

    // Hide the form and show the thank you message
    document.getElementById('expenseForm').style.display = 'none';
    document.getElementById('thankYouMessage').style.display = 'block';
}
